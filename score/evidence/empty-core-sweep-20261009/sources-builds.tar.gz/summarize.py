from pathlib import Path
import json, re
root=Path('/mnt/newdisk/code/CANN-challenge')
evidence=root/'score/evidence/empty-core-sweep-20261009'
records=[]
batches=[]
for i in range(1,4):
 p=evidence/f'batch{i}-oj.json'
 if not p.exists():continue
 r=json.loads(p.read_text());mapping=json.loads((evidence/f'batch{i}-mapping.json').read_text())
 rows=r['table'].splitlines()[1:]
 assert len(rows)==15
 for line,cores in zip(rows,mapping['core_counts']):
  cols=line.split('\t');assert cols[1]=='Wrong Answer',cols
  records.append({'batch':i,'point':int(cols[0]),'cores':cores,'duration_us':float(cols[3].replace('μs','')),'commit':r['commit'],'submission':r['submission']})
 batches.append(r)
(evidence/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
lines=['# 1～40核空kernel启动诊断（2026-10-09）','','正式计算版本：`747a06a`。诊断空AIV kernel不读取输入、不写输出，每次算子调用仅启动一次；全部WA为预期，诊断耗时不计入有效成绩。每种core数在任意测试点测量即可。','','三批分别为1～15核、16～30核、31～40核；第三批余下五点复测1/2/4/8/16核作为参照。不钳制core数量，启动参数就是表中core数。空核耗时包含平台测量条件，只能作为启动成本诊断，不能机械减去完整算子耗时。','','## 提交记录','','| 批次 | Git | OJ | 核数 | 完整结果观测上界秒 |','|---|---|---|---|---:|']
for i,r in reversed(list(enumerate(batches,1))):
 lines.append(f"| {i} | `{r['commit']}` | [{r['submission']}]({r['url']}) | {['1～15','16～30','31～40及五个参照'][i-1]} | {r['observed_upper_seconds']:.3f} |")
lines+=['','观测上界包含排队、编译、运行和观测延迟；小于300秒可保守确认远端编译未超过300秒，不是平台披露的独立编译时间。','','## 逐核结果','','| 核数 | 耗时μs | 批次/测试点 |','|---:|---:|---|']
for c in range(1,41):
 rr=[r for r in records if r['cores']==c]
 durations=" / ".join(format(r["duration_us"],".2f") for r in rr) or "待测"
 points=" / ".join(str(r["batch"])+"/"+str(r["point"]) for r in rr) or "待测"
 lines.append(f"| {c} | {durations} | {points} |")
lines+=['','各核数仅单次OJ观测（五个参照有复测），微小差异不能当作稳定差异。点1可能有首点异常，需结合参照判断。原始表、源码哈希、截图及核数映射均在同名evidence目录。']
(root/'score/1至40核空kernel启动诊断-20261009.md').write_text('\n'.join(lines)+'\n')
