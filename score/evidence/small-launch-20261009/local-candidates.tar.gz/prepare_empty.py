from pathlib import Path
import sys
f=Path(__file__).resolve().parent;s=(f/'baseline.asc').read_text(); cores=int(sys.argv[1])
a=s.index('extern "C" void run_kernel(');b=s.index('{',a)
probe='''// 仅用于启动成本诊断：不产生有效输出，OJ预期WA，不作为性能成绩。
__global__ __aicore__ void DiagnoseEmptyLaunch()
{
    KERNEL_TASK_TYPE_DEFAULT(KERNEL_TYPE_AIV_ONLY);
}

'''
body=f'''\n    using namespace batch_max_sum;
    DiagnoseEmptyLaunch<<<{cores}, nullptr, stream>>>();
    aclmdlRICaptureStatus captureStatus = ACL_MODEL_RI_CAPTURE_STATUS_NONE;
    aclmdlRI capturedModel = nullptr;
    CheckAcl(aclmdlRICaptureGetInfo(stream, &captureStatus, &capturedModel), "aclmdlRICaptureGetInfo");
    if (captureStatus != ACL_MODEL_RI_CAPTURE_STATUS_ACTIVE) {{
        CheckAcl(aclrtSynchronizeStream(stream), "aclrtSynchronizeStream");
    }}
#if 0 // 完整原始调度与特化保留，诊断结束恢复。
'''
s=s[:a]+probe+s[a:b+1]+body+s[b+1:]
s=s.rstrip()[:-1]+'#endif\n}\n'
Path('src/kernel.asc').write_text(s);(f/f'empty{cores}.asc').write_text(s)
