from pathlib import Path
import re
f=Path(__file__).resolve().parent;s=(f/'launch8.asc').read_text()
for name in ['ComputeDot32','ComputePackedDotsFixed']:
 start=s.index('__global__ __aicore__ void '+name+'(');end=s.index('\n}\n',start)+3
 body=s[start:end]
 specs=[]
 for match in re.finditer(r'    pipe.InitBuffer\((\w+),\s*(.*?)\);\n',body,re.S):
  var,sz=match.groups()
  if var.endswith('Queue'):sz=sz.removeprefix('1, ')
  specs.append((var,sz.replace('\n',' ')))
 declarations='    SetAtomicNone();\n    SetMaskNorm();\n    ResetMask();\n'
 previous=None
 for var,sz in specs:
  offset='0' if previous is None else f'({previous}Offset + {previous}Bytes + 31) / 32 * 32'
  declarations+=f'    constexpr uint32_t {var}Offset = {offset};\n    constexpr uint32_t {var}Bytes = {sz};\n'
  previous=var
 a=body.index('    TPipe pipe;');b=body.index('    GlobalTensor<T> a;',a)
 body=body[:a]+declarations+body[b:]
 for var,sz in specs:
  body=re.sub(rf'{var}\.Get<([^>]+)>\(\)',lambda m:f'LocalTensor<{m[1]}>(TPosition::VECCALC, {var}Offset, {var}Bytes / sizeof({m[1]}))',body)
  body=re.sub(rf'{var}\.AllocTensor<([^>]+)>\(\)',lambda m:f'LocalTensor<{m[1]}>(TPosition::VECCALC, {var}Offset, {var}Bytes / sizeof({m[1]}))',body)
 body=body.replace('    inputQueue.EnQue(input);','    SetFlag<HardEvent::MTE2_V>(EVENT_ID0);')
 body=body.replace('    input = inputQueue.DeQue<T>();','    WaitFlag<HardEvent::MTE2_V>(EVENT_ID0);')
 body=body.replace('    inputQueue.FreeTensor(input);','')
 body=body.replace('    outputQueue.EnQue(result);','    SetFlag<HardEvent::V_MTE3>(EVENT_ID0);')
 body=body.replace('    result = outputQueue.DeQue<float>();','    WaitFlag<HardEvent::V_MTE3>(EVENT_ID0);')
 body=body.replace('    outputQueue.FreeTensor(result);','')
 body=body[:-2]+'    PipeBarrier<PIPE_ALL>();\n}\n'
 s=s[:start]+body+s[end:]
(f/'static8.asc').write_text(s)
header=(f/'launch8-bridge.asc').read_text().replace('#include "launch8.asc"','#include "static8.asc"')
(f/'static8-bridge.asc').write_text(header)
