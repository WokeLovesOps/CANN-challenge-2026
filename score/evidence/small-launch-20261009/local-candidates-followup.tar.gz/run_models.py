from pathlib import Path
import os,subprocess,json,re,hashlib,sys
folder=Path(__file__).resolve().parent
records=[]
for name in sys.argv[1:]:
 for case in ([0,369,393,415] if name == "combined" else [0] if name in ["dotinplace","staticdot","maskdot"] else [369,393] if name in ["sum3","baseline3","blockmask3","earlyzero3"] else [415] if name in ["overlap4","baseline4","static4","fused4"] else [350] if name in ["compact2","mask2","repeat2"] else [0,350]):
  label=f'{name}-case{case}'; out=folder/'sim'/label;out.mkdir(parents=True,mode=0o700,exist_ok=True)
  report=out/'correctness.json'; log=out/'run.log'
  cmd=['msprof','op','simulator','--soc-version=Ascend910B3','--launch-count=2','--timeout=2',f'--output={out}/profile','python3','/mnt/newdisk/code/CANN-challenge/Build/opt-20261005/small/screen_alternating.py',str(folder/f'lib{name}.so'),f'--case={case}',f'--report={report}']
  print('开始',label,flush=True)
  with log.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,OPENBLAS_NUM_THREADS='2',OMP_NUM_THREADS='2',PYTHONDONTWRITEBYTECODE='1'))
  content=log.read_text(); r=json.loads(report.read_text()) if report.exists() else {'passed':False}
  r.update(variant=name,command=cmd,exit_code=p.returncode,source_sha256=hashlib.sha256((folder/f'{name}.asc').read_bytes()).hexdigest(),library_sha256=hashlib.sha256((folder/f'lib{name}.so').read_bytes()).hexdigest(),timings=[dict(core=c,duration_us=float(d),running_us=float(t)) for c,d,t in re.findall(r'(core\d+\.(?:veccore|cubecore)\d+)\s+(\d+(?:\.\d+)?)\s+(\d+(?:\.\d+)?)',content)],bins=[dict(path=str(b),size=b.stat().st_size,sha256=hashlib.sha256(b.read_bytes()).hexdigest()) for b in out.glob('profile/OPPROF_*/**/visualize_data.bin')])
  r['passed']=r['passed'] and p.returncode==0 and bool(r['bins']) and 'SIM_CORRECTNESS_PASS' in content
  records.append(r); (folder/f'{name}-models.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
  print(label,r['passed'],r['timings'],flush=True)
  if not r['passed']:sys.exit(1)
